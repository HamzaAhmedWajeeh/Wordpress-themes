<?php
// MENU TYPE
if ( ! function_exists( 'boldthemes_customize_menu_type' ) ) {
	function boldthemes_customize_menu_type( $wp_customize ) {
		
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_theme_options[menu_type]', array(
			'default'           => BoldThemes_Customize_Default::$data['menu_type'],
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'boldthemes_sanitize_select'
		));
		$wp_customize->add_control( 'menu_type', array(
			'label'     => esc_html__( 'Menu Type', 'amwerk' ),
			'description'    => esc_html__( 'Set the menu layout for all the pages on the site. Menu can be horizontal, in line with logo or below logo, or vertical on left or right, or fullscreen vertical hidden by default.', 'amwerk' ),
			'section'   => BoldThemesFramework::$pfx . '_header_footer_section',
			'settings'  => BoldThemesFramework::$pfx . '_theme_options[menu_type]',
			'priority'  => 60,
			'type'      => 'select',
			'choices'   => array(
				'horizontal-left'       => esc_html__( 'Horizontal Left', 'amwerk' ),
				'horizontal-center'     => esc_html__( 'Horizontal Centered', 'amwerk' ),
				'horizontal-right'      => esc_html__( 'Horizontal Right', 'amwerk' ),
				'horizontal-below-left'  => esc_html__( 'Horizontal Left Below Logo', 'amwerk' ),
				'horizontal-below-center'  => esc_html__( 'Horizontal Center Below Logo', 'amwerk' ),
				'horizontal-below-right' => esc_html__( 'Horizontal Right Below Logo', 'amwerk' ),
				'vertical-left'       => esc_html__( 'Vertical Left', 'amwerk' ),
				'vertical-right'      => esc_html__( 'Vertical Right', 'amwerk' ),
				'vertical-fullscreen' => esc_html__( 'Vertical Full Screen', 'amwerk' )
			)
		));
	}
}

