<?php

	echo '<section class="bt-comments gutter">';
		echo '<div class="port">';
			echo '<div class="bt-comments-content">';

			comments_template();

			echo '</div><!-- /bt_bb_column_content -->' ;
	
		echo '</div><!-- port -->';		
	echo '</section><!-- bt-comments -->';

?>